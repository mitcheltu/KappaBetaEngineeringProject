// Kappa Beta flotation device - signal simulation for Wokwi (ESP32-S3)
// Matches wiring schematic Rev E (2026-11-03).
//
// Real part (Rev E)                  -> what stands in for it in this simulation
//   BMI270 IMU (I2C SDA 8 / SCL 9)     -> MPU6050 on the same I2C pins. Click it while the
//                                         simulation runs to change tilt (accel) and rotation (gyro).
//   GY-MS5837-30BA depth sensor (I2C)  -> knob on GPIO 10 (Wokwi has no MS5837; 0 to 15 m)
//   MAX30102 heart rate + SpO2 (I2C)   -> Wokwi has no MAX30102, so:
//                                           knob on GPIO 11 = heart rate, 0 to 200 BPM
//                                           knob on GPIO 2  = SpO2, 50 to 100 %
//                                           slide switch on GPIO 42 = on skin (slide right = off skin)
//   Battery sense, R5/R6 divider (GPIO 1) -> knob on GPIO 1 (same pin and same math as the real board:
//                                           VBAT = 2 x ADC voltage). Starts at 3.9 V.
//   Cancel / SOS buttons (GPIO 5 / 6)  -> pushbuttons
//   Coin vibration motor (GPIO 7)      -> yellow LED
//   Solenoid valve via Q2 (GPIO 16)    -> blue LED (ON = valve open). Driven with PWM:
//                                         full power to pull it open, then ~50 % to hold it (Rev E note).
//
// Rev E firmware rules from the schematic notes:
//   - Valve held open with ~50 % PWM after pull-in.
//   - No valve below 3.4 V battery (VBAT = 2 x ADC on GPIO 1).
//
// All thresholds and time limits are DEMO values so a test runs in under a minute.

#include <Wire.h>

// ---------- Pins (Rev E) ----------
const int PIN_BAT_SENSE = 1;    // R5/R6 100k/100k divider from VBAT (real board and sim)
const int PIN_SPO2_SIM  = 2;    // simulation only: SpO2 knob
const int PIN_IMU_INT   = 4;    // BMI270 INT1 (not used yet)
const int PIN_CANCEL    = 5;
const int PIN_SOS       = 6;
const int PIN_MOTOR     = 7;
const int PIN_I2C_SDA   = 8;
const int PIN_I2C_SCL   = 9;
const int PIN_DEPTH_SIM = 10;   // simulation only: knob in place of the MS5837
const int PIN_HR_SIM    = 11;   // simulation only: heart-rate knob (moved off GPIO 1 for battery sense)
const int PIN_MAX_INT   = 15;   // MAX30102 INT on the real device (not used in the simulation)
const int PIN_SOLENOID  = 16;
const int PIN_SKIN_SIM  = 42;   // simulation only: LOW = sensor on skin

// ---------- Demo thresholds (tune later) ----------
const float IN_WATER_DEPTH_M   = 0.5;
const float SURFACE_DEPTH_M    = 1.0;
const float STILL_LIMIT_DPS    = 20.0;
const float FACE_DOWN_G        = -0.5;
const int   HR_LOW_BPM         = 30;
const int   HR_HIGH_BPM        = 180;
const int   SPO2_LOW_PCT       = 85;
const unsigned long STILL_TIME_MS       = 5000;
const unsigned long UNDERWATER_LIMIT_MS = 20000;
const unsigned long WARNING_TIME_MS     = 5000;
const unsigned long BUTTON_HOLD_MS      = 1000;
const unsigned long CONFIRM_BUZZ_MS     = 2000;
const unsigned long SOLENOID_OPEN_MS    = 4000;   // how long seawater is let in

// ---------- Rev E: battery and valve drive ----------
const float VALVE_MIN_VBAT     = 3.4;    // Rev E note: no valve below 3.4 V
const float LOW_BATT_WARN_V    = 3.6;    // flag in the log so a low battery is seen before a dive
const unsigned long SOL_PULLIN_MS = 200; // full power first so the valve snaps open (bench-test this)
const int   SOL_PWM_FREQ_HZ    = 20000;  // above hearing; change if the valve buzzes or won't hold
const int   SOL_PWM_BITS       = 8;
const int   SOL_HOLD_DUTY      = 128;    // ~50 % of 255 (Rev E note: PWM hold ~50 %)

// ---------- IMU over I2C ----------
// The simulation uses an MPU6050 (address 0x68). The real BMI270 uses different registers,
// so only imuBegin() and imuRead() change when you move to the real sensor.
const uint8_t IMU_ADDR = 0x68;
float accelZ = 1.0;
float rotationDps = 0;

bool imuBegin() {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);
  return Wire.endTransmission() == 0;
}

bool imuRead() {
  Wire.beginTransmission(IMU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(IMU_ADDR, (uint8_t)14) != 14) return false;
  int16_t raw[7];
  for (int i = 0; i < 7; i++) {
    uint8_t hi = Wire.read();
    uint8_t lo = Wire.read();
    raw[i] = (int16_t)((hi << 8) | lo);
  }
  accelZ = raw[2] / 16384.0;
  float gx = raw[4] / 131.0, gy = raw[5] / 131.0, gz = raw[6] / 131.0;
  rotationDps = sqrt(gx * gx + gy * gy + gz * gz);
  return true;
}

// ---------- Battery (same code works on the real board) ----------
float readBatteryV() {
  return 2.0 * analogReadMilliVolts(PIN_BAT_SENSE) / 1000.0;   // R5 = R6 = 100k, so VBAT = 2 x pin
}

// ---------- Solenoid PWM (LEDC) ----------
void solenoidPwmBegin() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PIN_SOLENOID, SOL_PWM_FREQ_HZ, SOL_PWM_BITS);
#else
  ledcSetup(0, SOL_PWM_FREQ_HZ, SOL_PWM_BITS);
  ledcAttachPin(PIN_SOLENOID, 0);
#endif
}
void solenoidDuty(int duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PIN_SOLENOID, duty);
#else
  ledcWrite(0, duty);
#endif
}

// ---------- State ----------
enum State { NORMAL, WARNING, EMERGENCY };
State state = NORMAL;

unsigned long underwaterSince = 0;
unsigned long stillSince      = 0;
unsigned long warningSince    = 0;
unsigned long emergencySince  = 0;
unsigned long cancelPressedAt = 0;
unsigned long sosPressedAt    = 0;
unsigned long lastPrint       = 0;
int solenoidMode = 0;            // 0 closed, 1 pull-in (100 %), 2 hold (~50 %), 3 blocked by low battery

bool heldLongEnough(int pin, unsigned long &pressedAt, unsigned long now) {
  if (digitalRead(pin) == LOW) {
    if (pressedAt == 0) pressedAt = now;
    return (now - pressedAt) >= BUTTON_HOLD_MS;
  }
  pressedAt = 0;
  return false;
}

void startEmergency(unsigned long now, const char *why) {
  state = EMERGENCY;
  emergencySince = now;
  Serial.println(why);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_CANCEL, INPUT_PULLUP);
  pinMode(PIN_SOS, INPUT_PULLUP);
  pinMode(PIN_SKIN_SIM, INPUT_PULLUP);
  pinMode(PIN_MOTOR, OUTPUT);
  analogSetAttenuation(ADC_11db);         // lets the ADC read up to about 3.1 V (battery sense)
  solenoidPwmBegin();
  solenoidDuty(0);                        // valve closed (normally closed)

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  bool imuFound = imuBegin();
  Serial.println("Flotation device simulation started (schematic Rev E)");
  Serial.println(imuFound ? "IMU found on I2C" : "IMU NOT found on I2C - check wiring");
  Serial.printf("Battery %.2f V%s\n", readBatteryV(), readBatteryV() < LOW_BATT_WARN_V ? "  LOW - charge before diving" : "");
}

void loop() {
  unsigned long now = millis();

  // ---------- 1. Read the sensors ----------
  bool imuOk = imuRead();

  int depthRaw = analogRead(PIN_DEPTH_SIM);
  bool depthFault = (depthRaw >= 4090);
  float depthM = depthRaw / 4095.0 * 15.0;

  int heartBpm = map(analogRead(PIN_HR_SIM), 0, 4095, 0, 200);
  int spo2Pct  = map(analogRead(PIN_SPO2_SIM), 0, 4095, 50, 100);
  bool onSkin  = (digitalRead(PIN_SKIN_SIM) == LOW);

  float vbat = readBatteryV();

  bool faceDown = imuOk && accelZ < FACE_DOWN_G;
  bool moving   = imuOk && rotationDps >= STILL_LIMIT_DPS;
  bool cancelHeld = heldLongEnough(PIN_CANCEL, cancelPressedAt, now);
  bool sosHeld    = heldLongEnough(PIN_SOS, sosPressedAt, now);

  bool inWater = (!depthFault && depthM > IN_WATER_DEPTH_M) || faceDown;

  // ---------- 2. Track how long conditions have lasted ----------
  if (!depthFault && depthM > SURFACE_DEPTH_M) { if (underwaterSince == 0) underwaterSince = now; }
  else underwaterSince = 0;

  if (imuOk && inWater && !moving) { if (stillSince == 0) stillSince = now; }
  else stillSince = 0;

  // ---------- 3. Add up warning signs ----------
  bool stillTooLong      = stillSince != 0 && (now - stillSince) > STILL_TIME_MS;
  bool underwaterTooLong = underwaterSince != 0 && (now - underwaterSince) > UNDERWATER_LIMIT_MS;
  bool faceDownAndStill  = faceDown && stillTooLong;
  bool heartAbnormal     = onSkin && (heartBpm < HR_LOW_BPM || heartBpm > HR_HIGH_BPM);
  bool lowSpO2           = onSkin && spo2Pct < SPO2_LOW_PCT;
  bool vitalsOk          = !heartAbnormal && !lowSpO2;

  int score = 0;
  if (stillTooLong)      score++;
  if (underwaterTooLong) score++;
  if (faceDownAndStill)  score++;
  if (heartAbnormal)     score++;
  if (lowSpO2)           score++;
  bool possibleDistress = inWater && score >= 2;

  // ---------- 4. Decide what to do ----------
  switch (state) {
    case NORMAL:
      if (sosHeld) {
        startEmergency(now, ">>> SOS pressed: going straight to EMERGENCY");
      } else if (possibleDistress) {
        state = WARNING;
        warningSince = now;
        Serial.println(">>> Possible distress: WARNING (hold Cancel to stop)");
      }
      break;

    case WARNING:
      if (cancelHeld || (moving && vitalsOk)) {
        state = NORMAL;
        stillSince = 0;
        underwaterSince = (underwaterSince != 0) ? now : 0;
        Serial.println(">>> Cancelled or movement detected: back to NORMAL");
      } else if (sosHeld) {
        startEmergency(now, ">>> SOS pressed during warning: EMERGENCY");
      } else if (now - warningSince > WARNING_TIME_MS) {
        startEmergency(now, ">>> No response: EMERGENCY");
      }
      break;

    case EMERGENCY:
      break;   // nothing cancels an emergency
  }

  // ---------- 5. Drive the outputs ----------
  bool blinkFast = (now / 150) % 2;
  bool blinkSlow = (now / 500) % 2;

  bool motorOn = false;
  int newMode = 0;
  if (state == WARNING) {
    motorOn = blinkSlow;
  } else if (state == EMERGENCY) {
    unsigned long t = now - emergencySince;
    motorOn = (t < CONFIRM_BUZZ_MS) && blinkFast;
    if (t < SOLENOID_OPEN_MS) {
      if (vbat < VALVE_MIN_VBAT) newMode = 3;          // Rev E rule: no valve below 3.4 V
      else newMode = (t < SOL_PULLIN_MS) ? 1 : 2;
    }
  }
  digitalWrite(PIN_MOTOR, motorOn ? HIGH : LOW);
  solenoidDuty(newMode == 1 ? 255 : newMode == 2 ? SOL_HOLD_DUTY : 0);

  if (newMode != solenoidMode) {
    if (newMode == 1) Serial.println(">>> Solenoid OPEN (100 % pull-in): seawater flowing to the reactants");
    else if (newMode == 2) Serial.println(">>> Solenoid HOLD at ~50 % PWM");
    else if (newMode == 3) Serial.printf(">>> Battery %.2f V is below %.1f V: valve NOT opened (Rev E rule)\n", vbat, VALVE_MIN_VBAT);
    else if (solenoidMode == 1 || solenoidMode == 2) Serial.println(">>> Solenoid CLOSED: water dose complete, bladder inflating");
    solenoidMode = newMode;
  }

  // ---------- 6. Print status twice a second ----------
  if (now - lastPrint > 500) {
    lastPrint = now;
    const char *names[] = {"NORMAL", "WARNING", "EMERGENCY"};
    const char *sol[] = {"closed", "OPEN  ", "HOLD  ", "BLOCKD"};
    char vitals[24];
    if (onSkin) snprintf(vitals, sizeof(vitals), "HR %3d | SpO2 %3d%%", heartBpm, spo2Pct);
    else snprintf(vitals, sizeof(vitals), "SENSOR OFF SKIN");
    Serial.printf("State: %-9s | depth %4.1f m | rotation %5.1f dps | face-down %s | %-17s | bat %.2f V | score %d || solenoid %s | motor %s%s%s%s\n",
                  names[state], depthM, rotationDps, faceDown ? "yes" : "no ", vitals, vbat, score,
                  sol[solenoidMode], motorOn ? "ON " : "off",
                  vbat < LOW_BATT_WARN_V ? " | LOW BATTERY" : "",
                  depthFault ? " | DEPTH FAULT" : "", imuOk ? "" : " | IMU FAULT");
  }

  delay(20);
}
